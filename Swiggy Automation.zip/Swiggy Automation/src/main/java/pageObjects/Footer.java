package pageObjects;

import org.openqa.selenium.WebDriver;

/**
 * Footer contains all the footer elements
 */
public class Footer {

    public WebDriver driver;

    // TODO header
    // company links
    // contact links
    // legal links
    // apple/google app links
    // weDeliverTo links
    // socialMedia links
}
