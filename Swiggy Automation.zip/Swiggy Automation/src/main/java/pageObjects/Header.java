package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Header contains all the header elements
 */
public class Header {

    // TODO header
    // public SearchPage searchPg;
    // public OffersPage offersPg;
    // public HelpPage helpPg;
    // public By SignIn
    // public CheckoutPage checkoutPg;

    public By location = By.xpath("//span[@class='_3HusE']");
}
